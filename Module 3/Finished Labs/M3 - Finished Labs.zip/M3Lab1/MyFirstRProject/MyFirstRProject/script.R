# x <- 1
y <- 2
z = 3

result <- x + y + z
rm(y)
rm(z)
ls()

varBool1 <- TRUE 
varBool2 <- FALSE
varbool1
varBool1
class(varBool2)
varChar <- "Text"
class(varChar)

help(class)
?class
??class

x <- c(1, 2, 3)
y <- c(4, 5, 6)
x
y

x + y

x * 3
y + 1

z <- c(TRUE, 1)
z2 <- c(1, 2, 3, "ABC")
z
z2

m <- matrix(1:10)
m
m * 2
m + 100
m1 <- matrix(1:10, ncol = 2)
m1
matrix(1:12, nrow = 5, byrow = TRUE)

m2 <- matrix(c(4, 3, 2, 17, 18, 19), nrow = 2, ncol = 3, byrow = TRUE, 
    dimnames = list(c("row1", "row2"), c("C1", "C2", "C3")))
m2
m2[1, 1]
m2["row1", "C2"]
m2[, 1]
m2[1,]

head(mtcars)
str(mtcars)
summary(mtcars)

df <- read.csv("E:\\Assets\\M2 - Lab 2\\sample_csv.csv", fill = TRUE, header = TRUE)
df
str(df)
df[, "C2"]
df[1:2,]

