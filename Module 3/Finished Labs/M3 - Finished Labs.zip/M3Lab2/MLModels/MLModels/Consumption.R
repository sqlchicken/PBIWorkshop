tail(mtcars) 
str(mtcars) 
summary(mtcars)

mpg <- mtcars$mpg
wt <- mtcars$wt
plot(wt, mpg, pch = 16, cex = 1.3, col = "blue", main = "Consumption (mpg x wt)", xlab = "wt", ylab = "mpg")

m <- lm(mpg ~ wt)
m

abline(m[[1]][1], m[[1]][2])

s <- mtcars[1:5,] # get first 5 lines
data.frame(actual = s$mpg, predict = predict(m, s))

